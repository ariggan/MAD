package cuboulder.aftertheupdate;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void toggleFunc(View view){
        ToggleButton toggle=(ToggleButton)findViewById(R.id.toggleButton);
        boolean toggleSays= toggle.isChecked();
        String outputStr;
        if(!toggleSays) {
            Context context=getApplicationContext();
            CharSequence text="You may want to wait until you are hungry to use this application.";
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(context,text,duration);
            toast.show();
        }
    }
    public String[] spinChoice(View view, String[] resultArray){
        String returnString[]=new String[3];
        Spinner choices=(Spinner)findViewById(R.id.spinner);
        String choiceType=String.valueOf(choices.getSelectedItem());
        switch (choiceType){
            case "I could snack":
                for(int i=0;i<3;i++){
                    returnString[i]=resultArray[i];
                }
            case "I'm pretty hungry":
                for(int i=3;i<6;i++){
                    returnString[i]=resultArray[i];
                }
            case "I'm STARVING!":
                for(int i=3;i<6;i++){
                    returnString[i]=resultArray[i];
                }
            default:
                for(int i=0;i<9;i++){
                    returnString[i]=resultArray[i];
                }
        }
        return returnString;
        //do a thing
    }
    public String[] radioFunc(View view, String[] resultArray){
        String returnString[]=new String[9];
        RadioGroup cost = (RadioGroup)findViewById(R.id.radioGroup);
        int whichOne=cost.getCheckedRadioButtonId();
        switch (whichOne){
            case 0:
                returnString[0]=resultArray[0];
            case 1:
                returnString[0]=resultArray[3];
            case 2:
                returnString[0]=resultArray[6];
            default:
                returnString=resultArray;
        }
        return returnString;
    }
    public Boolean checkItOut(View view){
        CheckBox secondBox=(CheckBox)findViewById(R.id.checkBox2);
        Boolean secondBool=secondBox.isChecked();
        if (secondBool){
            return true;
        }
        else{
            return false;
        }
    }
    public void rateIt(View view){
        RatingBar rateItItem = (RatingBar)findViewById(R.id.ratingBar);
        if (rateItItem.getRating()<3){
            Context context=getApplicationContext();
            CharSequence text="I'm sorry you didn't enjoy your meal recommendation!";
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(context,text,duration);
            toast.show();
        }
    }
    public void activateCascade(View view){
        String[] potentialMeals;
        potentialMeals= new String[]{"Apple", "Chips", "Cheese and Crackers", "Muffin with coffee", "Omelette","Eggs Benedict with Salmon", "Salad", "Sandwich", "Ratatouille"};

        if (checkItOut(view)){
        toggleFunc(view);
        String[] mealType;
        mealType=spinChoice(view,potentialMeals);
        String result[];
        result=radioFunc(view,mealType);

        TextView out = (TextView)findViewById(R.id.output);
        out.setText(result[0]);
        }
        else{
            Context context=getApplicationContext();
            CharSequence text="Please check the disclaimer box";
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(context,text,duration);
            toast.show();
        }
    }
}
